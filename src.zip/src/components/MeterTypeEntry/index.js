export { default } from './MeterTypeEntry';
