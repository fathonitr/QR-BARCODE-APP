export { default } from './SerialNumberScanner';
