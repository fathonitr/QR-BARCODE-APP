export { default } from './SubmissionScreen';
