export { default } from './DetailScreen';
